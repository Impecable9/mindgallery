import express from "express";
import { createServer as createViteServer } from "vite";
import cookieParser from "cookie-parser";
import { OAuth2Client } from "google-auth-library";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  const client = new OAuth2Client(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET
  );

  // In-memory store for user thoughts
  const userThoughts: Record<string, any[]> = {};
  // In-memory sessions
  const sessions: Record<string, any> = {};

  app.get("/api/auth/google/url", (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/google/callback`;
    const url = client.generateAuthUrl({
      access_type: "offline",
      scope: ["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email"],
      redirect_uri: redirectUri,
    });
    res.json({ url });
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    const { code } = req.query;
    const redirectUri = `${process.env.APP_URL}/api/auth/google/callback`;
    
    try {
      const { tokens } = await client.getToken({
        code: code as string,
        redirect_uri: redirectUri,
      });
      
      const ticket = await client.verifyIdToken({
        idToken: tokens.id_token!,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      
      const payload = ticket.getPayload();
      if (!payload) throw new Error("No payload");

      const sessionId = Math.random().toString(36).substring(7);
      sessions[sessionId] = {
        id: payload.sub,
        name: payload.name,
        email: payload.email,
        picture: payload.picture,
      };

      res.cookie("sessionId", sessionId, {
        httpOnly: true,
        secure: true,
        sameSite: "none",
      });

      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Authentication successful. This window should close automatically.</p>
          </body>
        </html>
      `);
    } catch (error) {
      console.error("Auth error:", error);
      res.status(500).send("Authentication failed");
    }
  });

  app.get("/api/auth/me", (req, res) => {
    const sessionId = req.cookies.sessionId;
    const user = sessions[sessionId];
    if (user) {
      res.json({ user });
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    const sessionId = req.cookies.sessionId;
    delete sessions[sessionId];
    res.clearCookie("sessionId");
    res.json({ success: true });
  });

  app.get("/api/thoughts/user", (req, res) => {
    const sessionId = req.cookies.sessionId;
    const user = sessions[sessionId];
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    res.json({ thoughts: userThoughts[user.id] || [] });
  });

  app.post("/api/thoughts", (req, res) => {
    const sessionId = req.cookies.sessionId;
    const user = sessions[sessionId];
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    
    const newThought = {
      ...req.body,
      id: `user-${Date.now()}`,
      author: user.name,
      isUserAdded: true,
    };
    
    if (!userThoughts[user.id]) userThoughts[user.id] = [];
    userThoughts[user.id].push(newThought);
    
    res.json({ thought: newThought });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
